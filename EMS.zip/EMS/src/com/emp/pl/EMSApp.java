package com.emp.pl;

import java.util.Scanner;

import com.emp.bean.EmployeeBean;
import com.emp.exception.EmployeeException;
import com.emp.service.EmployeeService;
import com.emp.service.EmployeeServiceImpl;


public class EMSApp {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter employee name: ");
		String name=sc.nextLine();
		
		System.out.println("Enter employee Salary: ");
		int salary=sc.nextInt();
		EmployeeBean bean=new EmployeeBean();
		bean.setEmployeeName(name);
		bean.setEmployeeSalary(salary);
		EmployeeService service=new EmployeeServiceImpl();
		
		try {
			int id=service.addEmployee(bean);
			System.out.println("Employee added successfully.\nID: "+id);
		} catch (EmployeeException e) {
			System.out.println(e);
		}
	}
}
