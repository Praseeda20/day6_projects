package com.emp.service;

import com.emp.bean.EmployeeBean;
import com.emp.dao.EmployeeDao;
import com.emp.dao.EmployeeDaoImpl;
import com.emp.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService {
	private EmployeeDao employeeDao = new EmployeeDaoImpl();

	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException {
		int id = employeeDao.addEmployee(bean);
		return id;
	}

}
